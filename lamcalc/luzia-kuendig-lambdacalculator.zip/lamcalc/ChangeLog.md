# Changelog for lamcalc

## Unreleased changes
