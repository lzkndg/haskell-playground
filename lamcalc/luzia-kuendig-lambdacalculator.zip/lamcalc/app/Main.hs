module Main where

import Lamcalc

main :: IO ()
main = someFunc
